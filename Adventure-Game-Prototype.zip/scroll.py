# scroll effect of text
import time
import sys

def scroll(letter):
  for i in letter:
    time.sleep(0.015)
    print (i, end = "")
    sys.stdout.flush()
  time.sleep(0.015)
  print()
  x = ""
  return x