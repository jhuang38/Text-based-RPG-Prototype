# List of all the Player Stats all the things they affect
stats = [20, 20, 2, 2, 1, 1, 0, 10, 0]
# indexes:
#0 - current hp 
#1 - max hp 
#2 - attack 
#3 - defense
#4 - player speed
#5 - player level
#6 - current exp
#7 - exp needed for level up
#8 - money
# Player Skills

skills=["Heal","Focus"]
weapon=""
armor=""
inventoryskills=["Heal","Focus"]
inventory=["Wooden Sword", "Worn Jacket"]
#index 0=hp, index 1=atk, index 2=def, index 3=spd
bufflist=["HP", "ATK", "DEF", "SPD"]
pointbuff=[0,0,0,0]

# why are you so bad

