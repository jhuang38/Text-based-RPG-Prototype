itemdict={
  "Wooden Sword": "A cheap wooden blade that you found at a toy store. Its blade doesn't even look sharp...", 
  "Worn Jacket": "A warm, slightly damaged jacket. Will it protect you well? Who knows...",
  "Piano": "3:45",
  "Scythe": "What? You were expecting more damage using a farming tool?",
  "Iron Sword": "Aww man...",
  "Hunting Knife": "A short blade that allows for swift strikes.",
  "Gun":"For his neutral special, he wields a gun.",
  "Thunder Blade":"A mystical blade that was forged with lightning.",
  "Shard of Vitality":"Crystal which increases life energy.",
  "Cloak of Swiftness":"A cloak that increases speed. How does a cape increase speed? Who knows...",
  "Iron Armor":"Good quality armor that will offer great protection. Can you move well in it? Probably not...",
  "Berserker's Armor":"Forged out of the tears of gamers when they tilt."
}
damagedict={
  "Wooden Sword": "+2 Damage. No special effects.",
  "Worn Jacket": "+1 Defense, +1 Max Health. No special effects.",
  "Piano": "+9999999999999999999999 Damage, +20 Speed. No special effects.",
  "Scythe":"+4 Damage. No special effects.",
  "Iron Sword": "+6 Damage. No special effects.",
  "Hunting Knife": "+5 Damage, +1 Speed. No special effects.",
  "Gun":"+10 Damage, Additional Skill: Quickdraw",
  "Thunder Blade": "+20 Damage, +2 Speed. Additional Skill: Storm Slash",
  "Shard of Vitality":"+10 Max Health.",
  "Cloak of Swiftness":"+3 Speed.",
  "Iron Armor":"+7 Defense, -2 Speed.",
  "Berserker's Armor":"+5 Max Health, +5 Defense, -1 Speed, +5 Damage."
}
itemstats={
  "Wooden Sword":[2,0,"weapon"],
  "Worn Jacket":[1,1,0,0],
  "Piano":[9999999999999999999999,20,"weapon"],
  "Scythe":[4,0,"weapon"],
  "Hunting Knife":[5,1,"weapon"],
  "Iron Sword":[6,0,"weapon"],
  "Gun":[10,0,"weapon"],
  "Thunder Blade":[20,2,"weapon"],
  "Shard of Vitality":[10,0,0,0],
  "Cloak of Swiftness":[0,0,3,0],
  "Iron Armor":[0,7,-2,0],
  "Berserker's Armor":[5,5,-1,5]
}
#for weapons:
#index0=damage bonus, index1=speedbonus, index2 is identifier for weapons
#for armor items:
#index0=healthbonus, #index1=armorbonus, #index2=armorspeedbonus, #index3=damagebonus

# list of everything in game
weapons=("Wooden Sword", "Piano", "Scythe", "Iron Sword", "Hunting Knife", "Gun", "Thunder Blade")
skillweapons={"Gun":"Quickdraw","Thunder Blade":"Storm Slash"}
specialskilldescs={
  "Quickdraw":"A faster attack that deals less damage.",
  "Storm Slash":"A lighting-fast slash that deals high damage. Requires a 1-turn recharge."
}
armors=("Worn Jacket", "Shard of Vitality", "Cloak of Swiftness", "Iron Armor", "Berserker's Armor")