dojoskills=[
  "Fortify",
  "Accelerate"
]

dojoprices={
  "Fortify":40,
  "Accelerate":40
}

skilldesc={
  "Heal":"Heals 20% of max health.",
  "Focus":"Increases damage of next attack.",
  "Fortify":"Increases defense for 2 turns.",
  "Accelerate":"Increases speed for 2 turns."
}