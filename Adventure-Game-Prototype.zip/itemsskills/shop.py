# shop items
shopitems=[
  "Scythe",
  "Iron Sword", 
  "Hunting Knife", 
  "Gun", 
  "Thunder Blade", 
  "Shard of Vitality", 
  "Cloak of Swiftness", 
  "Iron Armor", 
  "Berserker's Armor"
]
shopprices={
  "Scythe":20, # scythe
  "Iron Sword":35, # ironsword
  "Hunting Knife":35, # hunting knife
  "Gun":45, # gun-
  "Thunder Blade":100, # thunder blade
  "Shard of Vitality":40, #shard of vitality
  "Cloak of Swiftness":35, # cloak of Swiftness
  "Iron Armor":60, # iron armor
  "Berserker's Armor":80 # berserker's armor
}

