# Enemy 1
enname="Generic Slime"
enstats=[10, 10, 2, 1, 3, 1, 1, 3]
enskills=["Generic Slime released acidic fluids!","Generic Slime did... nothing!"]


#Index 0 - Current Hp
#Index 1 - Max HP
#Index 2 - Enemy Attack
#Index 3 - Enemy Defense
#Index 4 - Exp gained from killing
#Index 5 - Enemy Speed
#index 6 - enemy level
#index 7 - money gained from killing


#guide
#for attack messages, 1 is generic attack, 2+ is specials

