enname="Skeleton Warrior"
enstats=[30, 30, 20, -5, 50, 2, 10, 30]
enskills=[
  "Skeleton Warrior attacked with its bone sword!"
]
#Index 0 - Current Hp
#Index 1 - Max HP
#Index 2 - Enemy Attack
#Index 3 - Enemy Defense
#Index 4 - Exp gained from killing
#Index 5 - Enemy Speed
#index 6 - enemy level
#index 7 - money gained from killing


#guide
#for attack messages, 1 is generic attack, 2+ is specials