enname="Benevolent Despot Kim"
enstats=[99999, 99999, 99999, 99999, 3251258, 20, 99999, 99999]
enskills=[
  "Benevolent Despot Kim used Drive-by!",
  "Benevolent Despot Kim used Obliterate!"
]
#Index 0 - Current Hp
#Index 1 - Max HP
#Index 2 - Enemy Attack
#Index 3 - Enemy Defense
#Index 4 - Exp gained from killing
#Index 5 - Enemy Speed
#index 6 - enemy level
#index 7 - money gained from killing


#guide
#for attack messages, 1 is generic attack, 2+ is specials