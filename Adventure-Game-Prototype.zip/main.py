from playerstats import *
from scroll import scroll, time
from replit import clear
import random
from itemsskills.items import *
from itemsskills.shop import *
from itemsskills.dojo import *

# aight kiddos so this is the dumb checklist of things i wanna add
# 1. more enemies

# iffy additions
# - might add status effects (ie/burn/freeze/poison)
# - in future, will add different areas with bosses
#laziness
delay=0
# going through lists with number module
def listing(a, b):
  scroll(b)
  n=0
  time.sleep(delay)
  for i in range(len(a)):
    n+=1
    scroll(str(n)+" - " + a[i])
    time.sleep(delay)

# battle module
def battle():
  clear()
  stats[0]=stats[1]
  enstats[0]=enstats[1]
  scroll("%s appeared!" % enname)
  time.sleep(delay)
  focus="no"
  accel=-1
  fortturns=-1
  boost=0
  fortify=0
  skillatk=1
  skillspd=0
  recharge="no"
  move="recharge"
  while stats[0]>0 or enstats[0]>0:  
    scroll("%s: %d/%d HP, Lvl %d." % (name, stats[0], stats[1], stats[5]))
    time.sleep(delay)
    scroll("%s: %d/%d HP, Lvl %d." % (enname, enstats[0], enstats[1],enstats[6]))
    if accel>0:
      boost=3
      accel-=1
    elif accel==0:
      boost=0
      time.sleep(delay)
      scroll("%s returned to normal speed!" % name)
      accel=-1
    if fortturns>0:
      fortify=3
      fortturns-=1
    elif fortturns==0:
      fortify=0
      time.sleep(delay)
      scroll("%s's defenses returned to normal!" % name)
      fortturns=-1
    skillatk=1 # weapon memes
    skillspd=0
    skillnum=0
    if recharge=="no":
      time.sleep(delay)
      scroll("1 - Attack")
      time.sleep(delay)
      scroll("2 - Skills")
      time.sleep(delay)
      scroll("3 - Run")
      re = int(input())
      if re==1:
        move="attack"
      elif re==2:
        n=0
        for i in range(len(skills)):
          n+=1
          scroll(str(n) + " - " + skills[n-1])
          time.sleep(delay)
        if weapon in skillweapons:
          n+=1
          scroll(str(n) + " - " + skillweapons[weapon])
          time.sleep(delay)
        skillnum=int(input())
        move="skill"
        time.sleep(delay)
      elif re==3:
        time.sleep(delay)
        if name=="Joseph Joestar":
          scroll("NIGERUNDAYO!!")
        else:
          scroll("You ran away! Coward...")
        time.sleep(1)
        clear()
        break
    elif recharge=="yes":
      recharge="no"
      move="recharge"
    if skillnum==3 and skillweapons[weapon]=="Quickdraw":
      scroll("You prepared to draw your gun!")
      skillatk=0.75
      skillspd=1.5
      move="attack"
    if skillnum==3 and skillweapons[weapon]=="Storm Slash" and recharge=="no" and move != "recharge":
      scroll("The smell of ozone fills the air!")
      skillatk=1.8
      skillspd=3
      move="attack"
      recharge="yes"
    if enstats[5]>=stats[4]+boost+skillspd:
      a=random.choice(enskills)
      time.sleep(delay)
      scroll(a)
      if a == enskills[0]:
        # damage formula goes here
        stats[0]-=round((enstats[6]*enstats[2])/(stats[5]*stats[3]+fortify))
        if stats[0]<=0 or enstats[0]<=0:
          break
      else:
        if a == "Generic Slime did... nothing!":
          time.sleep(delay)
        if a == "Benevolent Despot Kim used Obliterate!":
          stats[0]=-1
        if stats[0]<=0 or enstats[0]<=0:
          break
      if move=="recharge":
        scroll("%s needs to recharge from their last attack!" % name)
      elif move=="attack" or move=="skill" and skills[skillnum-1]=="":
        scroll("You attacked %s!" % enname)
        if focus=="yes":
          enstats[0]-=round((skillatk*stats[5]*1.5*stats[2])/(enstats[6]*enstats[3]))
          focus="no"
        else:
          enstats[0]-=round((stats[5]*skillatk*stats[2])/(enstats[6]*enstats[3]))
        if stats[0]<=0 or enstats[0]<=0:
          break
      elif move=="skill":
        scroll("You used %s!" % skills[skillnum-1])
        time.sleep(delay)
        if skills[skillnum-1]=="Heal":
          stats[0]+=round(0.2*stats[0])
          if stats[0]>stats[1]:
            stats[0]=stats[1]
          scroll("HP restored.")
        elif skills[skillnum-1]=="Focus":
          focus="yes"
          scroll("%s focused!" % name)
        elif skills[skillnum-1]=="Accelerate":
          accel=3
          scroll("%s's speed increased!" % name)
        elif skills[skillnum-1]=="Fortify":
          fortturns=3
          scroll("%s braced themselves for incoming attacks!" % name)
      time.sleep(delay)
    elif enstats[5]<stats[4]+boost+skillspd:
      if move=="recharge":
        scroll("%s needs to recharge from their last attack!" % name)
      elif move=="attack" or move=="skill" and skills[skillnum-1]=="":
        scroll("You attacked %s!" % enname)
        if focus=="yes":
          enstats[0]-=round((skillatk*stats[5]*1.5*stats[2])/(enstats[6]*enstats[3]))
          focus="no"
        else:
          enstats[0]-=round((stats[5]*skillatk*stats[2])/(enstats[6]*enstats[3]))
        if stats[0]<=0 or enstats[0]<=0:
          break
      elif move=="skill":
        scroll("You used %s!" % skills[skillnum-1])
        time.sleep(delay)
        if skills[skillnum-1]=="Heal":
          stats[0]+=round(0.2*stats[0])
          if stats[0]>stats[1]:
            stats[0]=stats[1]
          scroll("HP restored.")
        elif skills[skillnum-1]=="Focus":
          focus="yes"
          scroll("%s focused!" % name)
        elif skills[skillnum-1]=="Accelerate":
          accel=3
          scroll("%s's speed increased!")
        elif skills[skillnum-1]=="Fortify":
          fortturns=3
          scroll("%s braced themselves for incoming attacks!" % name)
      time.sleep(delay)
      a=random.choice(enskills)
      time.sleep(delay)
      scroll(a)
      if a == enskills[0]:
        # damage formula goes here
        stats[0]-=round((enstats[6]*enstats[2])/(stats[5]*stats[3]+fortify))
        if a == "Generic Slime did... nothing!":
          print()
        if a == "Benevolent Despot Kim used Obliterate!":
          stats[0]=-1
        if stats[0]<=0 or enstats[0]<=0:
          break
        time.sleep(delay)
    if stats[0]<=0 or enstats[0]<=0:
      break
  if stats[0]<=0 and enstats[0]>0:
    time.sleep(delay)
    scroll("You lost the battle!")
    time.sleep(delay)
    scroll("You blacked out...")
    time.sleep(delay)
    stats[8]-=round((0.1*stats[8])+2)
    if stats[8]<0:
      stats[8]=0
    clear()
    # probably add some part where you lose money and a chance of losing weapons
  elif stats[0]>0 and enstats[0]<=0:
    time.sleep(delay)
    scroll("You defeated %s!" % enname)
    time.sleep(delay)
    scroll("You gained %d experience points!" % enstats[4])
    time.sleep(delay)
    scroll("You gained %d coins!" % enstats[7])
    stats[6]+=enstats[4]
    stats[8]+=enstats[7]
    if stats[6]>=stats[7]: # making sure you're actually wearing armor
      if armor!="":
        stats[1]-=itemstats[armor][0]#health
        stats[2]-itemstats[armor][3]#armordamage
        stats[3]-=itemstats[armor][1]#defense
        stats[4]-=itemstats[armor][2]#armorspeedbonus
      if weapon!="":
        stats[2]-=itemstats[weapon][0]#weapondamage
        stats[4]-=itemstats[weapon][1]#weaponspeedbonus
      while stats[6]>=stats[7]:
        time.sleep(delay)
        prevhp=stats[1]
        prevatk=stats[2]
        prevdef=stats[3]
        prevspd=stats[4]
        stats[5]+=1
        stats[1]=round(1.092**(stats[5]+pointbuff[0])+19)
        stats[2]=round(1.0855**(stats[5]+pointbuff[1])+stats[5]+pointbuff[1])
        stats[3]=round(1.0855**(stats[5]+pointbuff[2])+stats[5]+pointbuff[2])
        stats[4]=round(1.05**(stats[5]+pointbuff[3])+1+pointbuff[3])
        stats[6]-=stats[7]
        stats[7]=(2*(stats[5])**3)+8
        scroll("You leveled up to lvl %d!" % stats[5])
        time.sleep(delay)
        scroll("Max HP: +%d, ATK: +%d, DEF: +%d, SPD: +%d" % (stats[1]-prevhp,stats[2]-prevatk,stats[3]-prevdef,stats[4]-prevspd))
        if stats[5]/5==stats[5]//5 and stats[5]<=50:
          scroll("Please choose an extra stat to level up.")
          listing(bufflist,"")
          while True:
            try:
              c=int(input())
              pointbuff[c-1]+=1
              scroll("You have decided to level up %s." % bufflist[c-1])
              break
            except ValueError:
              scroll("Please choose a valid option.")
              time.sleep(delay)
      if armor!="":
        stats[1]+=itemstats[armor][0]#health
        stats[2]+=itemstats[armor][3]#armordamage
        stats[3]+=itemstats[armor][1]#defense
        stats[4]+=itemstats[armor][2]#armorspeedbonus
      if weapon!="":
        stats[2]+=itemstats[weapon][0]#weapondamage
        stats[4]+=itemstats[weapon][1]#weaponspeedbonus    
    time.sleep(delay)
    clear()

# actual memes
scroll("Welcome to Adventure Game Engine Test.")
time.sleep(delay)
scroll("What is your name?")
time.sleep(delay)
name=input(">")
clear()
time.sleep(delay)
while True:
  scroll("Tranquil Fields")
  print("----------------")
  time.sleep(delay)
  scroll("1 - Wander")
  time.sleep(delay)
  scroll("2 - Character")
  time.sleep(delay)
  scroll("3 - Inventory")
  time.sleep(delay)
  scroll("4 - Skills")
  time.sleep(delay)
  scroll("5 - Store")
  time.sleep(delay)
  scroll("6 - Dojo")
  time.sleep(delay)
  scroll("7 - Quit")
  time.sleep(delay)
  a=input()
  if a == "1":
    battling = random.choice([1,2])
    if battling == 1:
      from enemies.slime import *
    elif battling == 2:
      from enemies.skeleton import *
    battle()
  elif a == "2":
    clear()
    time.sleep(delay)
    scroll(name + "")
    time.sleep(delay)
    scroll("LVL %d" % stats[5])
    time.sleep(delay)
    scroll("%d Max HP (%d skill points)" % (stats[1],pointbuff[0]))
    time.sleep(delay)
    scroll("%d ATK (%d skill points)" % (stats[2],pointbuff[1]))
    time.sleep(delay)
    scroll("%d DEF (%d skill points)" % (stats[3],pointbuff[2]))
    time.sleep(delay)
    scroll("%d SPD (%d skill points)" % (stats[4],pointbuff[3]))
    time.sleep(delay)
    scroll("%d EXP" % stats[6])
    time.sleep(delay)
    scroll("%d EXP required for next level" % (stats[7]-stats[6]))
    time.sleep(delay)
    scroll("%d Coins" % stats[8])
    time.sleep(delay)
    scroll("Weapon: %s" % weapon)
    time.sleep(delay)
    scroll("Armor: %s" % armor)
    time.sleep(delay)
    scroll("Skill 1: %s" % skills[0])
    time.sleep(delay)
    scroll("Skill 2: %s" % skills[1])
    time.sleep(delay)
    try:
      scroll("Weapon Skill: %s" % skillweapons[weapon])
    except KeyError:
      print()
    input("Press any key to continue...")
  elif a == "3":
    scroll("Weapon: %s" % weapon)
    time.sleep(delay)
    scroll("Armor: %s" % armor)
    time.sleep(delay)
    listing(inventory, "Inventory:")
    time.sleep(delay)
    scroll("Select the items you want to interact with.")
    try:
      equip=int(input())
      scroll("Item: %s" % inventory[equip-1])
      time.sleep(delay)
      scroll(damagedict[inventory[equip-1]])
      time.sleep(delay)
      scroll(itemdict[inventory[equip-1]])
      time.sleep(delay)
      if inventory[equip-1] in skillweapons:
        scroll("Weapon Skill: %s" % skillweapons[inventory[equip-1]])
        time.sleep(delay)
        scroll(specialskilldescs[skillweapons[inventory[equip-1]]])
        time.sleep(delay)
      scroll("Do you want to equip/de-equip %s? (Y/N)" % inventory[equip-1])
      meep=input().lower().strip(".,!?&")
      if meep=="y" or meep =="yes":
        if inventory[equip-1] == weapon or inventory[equip-1] == armor:
          if inventory[equip-1] == weapon:
            scroll("You have de-equipped %s." % weapon)
            stats[2]-=itemstats[inventory[equip-1]][0] # attack
            stats[4]-=itemstats[inventory[equip-1]][1] # speed
            weapon=""
          elif inventory[equip-1] == armor:
            scroll("You have de-equipped %s." % armor)
            stats[0]-=itemstats[inventory[equip-1]][0] # current health
            stats[1]-=itemstats[inventory[equip-1]][0] # max health
            stats[3]-=itemstats[inventory[equip-1]][1] # defense
            stats[4]-=itemstats[inventory[equip-1]][2] #speed
            stats[2]-=itemstats[inventory[equip-1]][3] # damage
            armor==""
        # swapping weapons/armor if already equipped
        elif weapon!="" and inventory[equip-1] in weapons:
          scroll("You have de-equipped %s." % weapon)
          stats[2]-=itemstats[weapon][0] # attack
          stats[4]-=itemstats[weapon][1] # speed
          stats[2]+=itemstats[inventory[equip-1]][0] # attack
          stats[4]+=itemstats[inventory[equip-1]][1] # speed
          weapon=inventory[equip-1]
          time.sleep(delay)
          scroll("You equipped %s!" % weapon)
        elif armor!="" and inventory[equip-1] in armors:
          scroll("You have de-equipped %s." % armor)
          stats[0]-=itemstats[armor][0] # current health
          stats[1]-=itemstats[armor][0] # max health
          stats[3]-=itemstats[armor][1] # defense
          stats[4]-=itemstats[armor][2] #speed
          stats[2]-=itemstats[armor][3] # damage
          stats[0]+=itemstats[inventory[equip-1]][0] # current health
          stats[1]+=itemstats[inventory[equip-1]][0] # max health
          stats[3]+=itemstats[inventory[equip-1]][1] # defense
          stats[4]+=itemstats[inventory[equip-1]][2] #speed
          stats[2]+=itemstats[inventory[equip-1]][3] # damage
          armor=inventory[equip-1]
          time.sleep(delay)
          scroll("You equipped %s!" % armor)
        else:
          #check if thing is weapon or armor
          if itemstats[inventory[equip-1]][2]=="weapon":
            stats[2]+=itemstats[inventory[equip-1]][0] # attack
            stats[4]+=itemstats[inventory[equip-1]][1] # speed
            weapon=inventory[equip-1]
            scroll("You equipped %s!" % weapon)
          # in this case, it should be a piece of armor
          elif itemstats[inventory[equip-1]][2]!="weapon":
            stats[0]+=itemstats[inventory[equip-1]][0] # current health
            stats[1]+=itemstats[inventory[equip-1]][0] # max health
            stats[3]+=itemstats[inventory[equip-1]][1] # defense
            stats[4]+=itemstats[inventory[equip-1]][2] #speed
            stats[2]+=itemstats[inventory[equip-1]][3] # damage
            armor=inventory[equip-1]
            scroll("You equipped %s!" % armor)
        time.sleep(delay)
        input("Press any key to continue...")
    except ValueError:
      print()
    clear()
    time.sleep(delay)
  elif a =="4":
    scroll("Skill 1: %s" % skills[0])
    time.sleep(delay)
    scroll("Skill 2: %s" % skills[1])
    time.sleep(delay)
    try:
      scroll("Weapon Skill: %s" % skillweapons[weapon])
    except KeyError:
      scroll("Weapon Skill:")
    time.sleep(delay)
    listing(inventoryskills, "Select the skills you wish to equip/de-equip. Press any other key to continue.")
    try:
      skillselect=int(input())
      scroll("Skill: %s" % inventoryskills[skillselect-1])
      time.sleep(delay)
      scroll(skilldesc[inventoryskills[skillselect-1]])
      time.sleep(delay)
      scroll("Are you sure you want to equip/de-equip %s? (Y/N)" % inventoryskills[skillselect-1])
      meep=input().lower().strip(".,!?&")
      if meep=="y" or meep =="yes":
        if inventoryskills[skillselect-1] in skills:
          replace=skills.index(inventoryskills[skillselect-1])
          skills[replace]=""
          scroll("You have successfully de-equipped %s." % inventoryskills[skillselect-1])
          if skills[0]=="":
            skills[0]=skills[1]
            skills[1]=""
        else:
          if skills.count("")==0:
            scroll("You already have 2 skills equipped! Please de-equip another first.")
          elif skills.count("")!=0:
            replace=inventoryskills[skillselect-1]
            scroll("You have succesfully equipped %s." % replace)
            if skills[1]=="":
              skills[1]=replace
          
    except ValueError:
      print()
    time.sleep(delay)
    input("Press any key to continue...")
  elif a == "5":
    clear()
    scroll("Shopkeeper: Welcome to the shop! We are selling:")
    time.sleep(delay)
    listing(shopitems, "")
    time.sleep(delay)
    scroll("Your Balance: %d coins." % stats[8])
    time.sleep(delay)
    scroll("To get information about an item in the shop, type its corresponding number. To continue, press any other key.")
    try:
      item=int(input())
      if item<=len(shopitems):
        scroll(shopitems[item-1])
        time.sleep(delay)
        scroll("Price: %d coins." % shopprices[shopitems[item-1]])
        time.sleep(delay)
        scroll(damagedict[shopitems[item-1]])
        time.sleep(delay)
        scroll(itemdict[shopitems[item-1]])
        time.sleep(delay)
        scroll("Your Balance: %d coins." % stats[8])
        time.sleep(delay)
        scroll("Would you like to buy? (Y/N)")
        r=input().lower().strip("!.,?")
        if r=="yes"or r =="y":
          if stats[8]>=shopprices[shopitems[item-1]]:
            inventory.append(shopitems[item-1])
            stats[8]-=shopprices[shopitems[item-1]]
            scroll("Your purchase was a sucess!")
          else:
            scroll("You don't have enough money!")
        input("Press any key to continue...")
    except ValueError:
      print()
    time.sleep(delay)
  elif a=="6":
    clear()
    scroll("Sensei: Welcome to the Dojo!")
    time.sleep(delay)
    listing(dojoskills, "Skills")
    time.sleep(delay)
    scroll("Your Balance: %d coins." % stats[8])
    time.sleep(delay)
    scroll("To get information about an item in the dojo, type its corresponding number. To continue, press any other key.")
    try:
      item=int(input())
      if item<=len(dojoskills):
        scroll(dojoskills[item-1])
        time.sleep(delay)
        scroll("Price: %d coins." % dojoprices[dojoskills[item-1]])
        time.sleep(delay)
        scroll(skilldesc[dojoskills[item-1]])
        scroll("Your Balance: %d coins." % stats[8])
        time.sleep(delay)
        scroll("Would you like to buy? (Y/N)")
        r=input().lower().strip("!.,?")
        if r=="yes"or r =="y":
          if stats[8]>=dojoprices[dojoskills[item-1]]:
            inventoryskills.append(shopitems[item-1])
            stats[8]-=dojoprices[dojoskills[item-1]]
            scroll("Your purchase was a sucess!")
          else:
            scroll("Come back when you have more funds, grasshopper...")
    except ValueError:
      print()
    time.sleep(delay)
    input("Press any key to continue...")
  elif a == "7":
    clear()
    a=input(scroll('Are you sure you want to quit?')).lower().strip(".,!/-_>?<")
    if a == "y" or a == "yes":
      break
    else:
      clear()
  elif a=="8":
    from enemies.kim import *
    battle()
  time.sleep(delay)
  clear()
quit()